JUNGLE RUSH 3D - JUNGLE UPGRADE

Extract this ZIP and open index.html in Chrome. No external libraries are needed; it can run offline once extracted.
Tap START RUN. Swipe or use arrows to change lanes, jump, and slide.
This is still a browser prototype, not an installable Android APK or a Play Store-ready release.
